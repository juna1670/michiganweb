import { categories, marketTypes, type PostRow } from '@/lib/types';

type Props = {
  mode: 'create' | 'edit';
  action: string;
  post?: PostRow;
};

export default function PostForm({ mode, action, post }: Props) {
  const isEdit = mode === 'edit';

  return (
    <form action={action} method="post" encType="multipart/form-data" className="page-stack">
      <div className="card-flat">
        <div className="split-actions">
          <h2 className="card-title" style={{ margin: 0 }}>基本情報</h2>
          <div className="small">入力項目 6個</div>
        </div>
        <div className="form-grid">
          <input name="title" placeholder="タイトル" required maxLength={100} defaultValue={post?.title || ''} />
          <select name="category" required defaultValue={post?.category || ''}>
            <option value="" disabled>カテゴリを選択</option>
            {categories.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <select name="marketType" defaultValue={post?.marketType || ''}>
            <option value="">フリマ以外は未選択</option>
            {marketTypes.map((m) => <option key={m} value={m}>{m}</option>)}
          </select>
          <input name="area" placeholder="地域（例: Novi, Ann Arbor）" maxLength={60} defaultValue={post?.area || ''} />
          <input name="price" type="number" step="0.01" placeholder="価格 USD（任意）" defaultValue={typeof post?.price === 'number' ? String(post.price) : ''} />
          <input name="contact" placeholder="連絡先（Email など）" maxLength={120} defaultValue={post?.contact || ''} />
        </div>
      </div>

      {isEdit && post && post.imagePaths.length > 0 ? (
        <div className="card-flat">
          <div className="split-actions">
            <h2 className="card-title" style={{ margin: 0 }}>現在の画像</h2>
            <div className="small">{post.imagePaths.length} 枚</div>
          </div>
          <div className="image-grid">
            {post.imagePaths.map((img, index) => (
              <label key={img} className="row-card" style={{ padding: 12 }}>
                <img src={img} alt={`image-${index + 1}`} className="post-image" />
                <div style={{ marginTop: 10, display: 'flex', gap: 8, alignItems: 'center' }}>
                  <input type="checkbox" name="removeImages" value={img} style={{ width: 18, height: 18 }} />
                  <span>この画像を削除</span>
                </div>
              </label>
            ))}
          </div>
        </div>
      ) : null}

      <div className="card-flat">
        <div className="split-actions">
          <h2 className="card-title" style={{ margin: 0 }}>本文と画像</h2>
          <div className="small">画像 最大 4枚</div>
        </div>
        <div className="page-stack">
          <div>
            <label className="small" htmlFor="images">画像アップロード（JPG / PNG / WEBP）</label>
            <input id="images" name="images" type="file" accept="image/*" multiple />
          </div>
          <textarea name="body" placeholder="本文" required maxLength={4000} defaultValue={post?.body || ''} />
        </div>
      </div>

      <div className="actions">
        <button className="primary" type="submit">{isEdit ? '更新して再申請する' : '投稿して承認待ちに送る'}</button>
      </div>
    </form>
  );
}
