import Link from 'next/link';
import { getCurrentUser } from '@/lib/auth';
import { countPendingPosts } from '@/lib/db';

export default async function Header() {
  const user = await getCurrentUser();
  const pendingCount = user?.role === 'admin' ? countPendingPosts() : 0;

  return (
    <header className="topbar">
      <div className="container topbar-inner">
        <Link href="/" className="brand">
          <span className="brand-mark">井</span>
          <span>ミシガンいどばた+</span>
        </Link>

        <form action="/" method="get" className="top-search">
          <span aria-hidden="true">🔍</span>
          <input name="q" placeholder="投稿、地域、学校、売りたい物を検索" />
        </form>

        <nav className="nav">
          <Link href="/">ホーム</Link>
          <Link href="/posts/new" className="nav-primary">投稿する</Link>
          {user ? (
            <>
              <Link href="/dashboard">マイ投稿</Link>
              {user.role === 'admin' ? <Link href="/admin">承認管理{pendingCount > 0 ? ` ${pendingCount}` : ''}</Link> : null}
              <form action="/api/auth/logout" method="post">
                <button type="submit">ログアウト</button>
              </form>
            </>
          ) : (
            <>
              <Link href="/login">ログイン</Link>
              <Link href="/register">会員登録</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
