import { redirect } from 'next/navigation';
import Link from 'next/link';
import { getCurrentUser } from '@/lib/auth';
import { countPendingPosts, getPosts } from '@/lib/db';

export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user) redirect('/login?error=ログインが必要です');
  if (user.role !== 'admin') redirect('/dashboard');

  const pendingPosts = getPosts({ status: 'pending', includeAllStatuses: true });
  const rejectedPosts = getPosts({ status: 'rejected', includeAllStatuses: true });
  const approvedPosts = getPosts({ status: 'approved', includeAllStatuses: true }).slice(0, 10);
  const pendingCount = countPendingPosts();

  return (
    <main className="page-section">
      <div className="container layout-shell">
        <aside className="sidebar hide-mobile">
          <div className="card-flat">
            <h2 className="card-title">承認オペレーション</h2>
            <div className="table-like">
              <div className="row-card"><strong>承認待ち</strong><div className="small">{pendingPosts.length} 件</div></div>
              <div className="row-card"><strong>差し戻し</strong><div className="small">{rejectedPosts.length} 件</div></div>
              <div className="row-card"><strong>最近の公開</strong><div className="small">{approvedPosts.length} 件</div></div>
            </div>
          </div>
        </aside>

        <section className="main-column">
          <div className="card hero-card">
            <span className="badge">管理者画面</span>
            <h1 className="hero-title" style={{ fontSize: 34, marginTop: 10 }}>承認待ち {pendingCount} 件をすぐ処理できる管理UIです。</h1>
            <p className="hero-copy">一覧から内容確認、承認、差し戻しまで最短 2クリックで進められるようにしています。</p>
          </div>

          <section className="page-stack">
            <h2 className="card-title" style={{ marginBottom: 0 }}>承認待ち {pendingPosts.length} 件</h2>
            {pendingPosts.map((post) => (
              <div key={post.id} className="card feed-card">
                <div className="feed-head">
                  <div>
                    <div className="actions">
                      <span className="badge">{post.category}</span>
                      {post.marketType ? <span className="badge market">{post.marketType}</span> : null}
                      <span className="badge pending">承認待ち</span>
                    </div>
                    <h3 className="feed-title">{post.title}</h3>
                    <div className="feed-meta">投稿者 {post.authorName} / 画像 {post.imagePaths.length} 枚 / 投稿日 {post.createdAt}</div>
                  </div>
                  <div className="small">#{post.id}</div>
                </div>
                <div className="actions">
                  <Link href={`/posts/${post.id}`} className="secondary">確認</Link>
                  <form action={`/api/admin/posts/${post.id}/approve`} method="post">
                    <button type="submit" className="primary">承認</button>
                  </form>
                  <form action={`/api/admin/posts/${post.id}/reject`} method="post">
                    <button type="submit" className="danger">差し戻し</button>
                  </form>
                </div>
              </div>
            ))}
            {pendingPosts.length === 0 ? <div className="notice">承認待ちは 0 件です。</div> : null}
          </section>

          <section className="page-stack">
            <h2 className="card-title" style={{ marginBottom: 0 }}>差し戻し {rejectedPosts.length} 件</h2>
            {rejectedPosts.slice(0, 10).map((post) => (
              <div key={post.id} className="card-flat">
                <strong>{post.title}</strong>
                <div className="small">投稿者 {post.authorName} / 更新日 {post.updatedAt || '-'}</div>
              </div>
            ))}
          </section>
        </section>

        <aside className="sidebar">
          <div className="card-flat">
            <h2 className="card-title">最近の公開投稿</h2>
            <div className="table-like">
              {approvedPosts.map((post) => (
                <div key={post.id} className="row-card">
                  <strong>{post.title}</strong>
                  <div className="small">{post.authorName} / 画像 {post.imagePaths.length} 枚</div>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
}
