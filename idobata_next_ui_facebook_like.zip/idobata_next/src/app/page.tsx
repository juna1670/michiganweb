import Link from 'next/link';
import { getPosts, countPendingPosts } from '@/lib/db';
import { categories } from '@/lib/types';

const categoryDescriptions: Record<string, string> = {
  '井戸端掲示板': '生活相談、学校、地域情報、雑談向け。',
  'フリマ': '売ります・買います・譲ります・探していますを分離。',
  '案内・募集': 'イベント、習い事、求人、友達募集など。',
  '不動産': '賃貸、売買、ルームメイト、短期滞在向け。',
};

function getInitial(name?: string) {
  return name?.trim()?.[0] || '井';
}

export default function Home({ searchParams }: { searchParams?: { category?: string; marketType?: string; q?: string } }) {
  const posts = getPosts(searchParams);
  const pendingCount = countPendingPosts();
  const marketPosts = getPosts({ category: 'フリマ' });

  return (
    <main className="page-section">
      <div className="container page-stack">
        <section className="card hero-card">
          <div className="hero-grid">
            <div>
              <span className="badge">UI 4.0 / SNS風ナビゲーション</span>
              <h1 className="hero-title">Facebookに近い操作感で、地域掲示板の良さを残したUIに改善しました。</h1>
              <p className="hero-copy">
                1. 上部固定ナビ、2. すぐ検索できる導線、3. カード型フィード、4. 右側の要点表示、5. モバイル最適化、
                6. フリマ専用導線、7. 投稿から公開までの流れを見える化、の <strong>7点</strong> を強化しています。
              </p>
              <div className="actions" style={{ marginTop: 16 }}>
                <Link href="/posts/new" className="primary">今すぐ投稿する</Link>
                <Link href="/register" className="secondary">会員登録</Link>
              </div>
            </div>
            <div className="kpi-grid">
              <div className="kpi"><strong>{categories.length}</strong><span className="muted">主要カテゴリ</span></div>
              <div className="kpi"><strong>4</strong><span className="muted">フリマ細分類</span></div>
              <div className="kpi"><strong>{posts.length}</strong><span className="muted">公開中の投稿</span></div>
              <div className="kpi"><strong>{pendingCount}</strong><span className="muted">承認待ち投稿</span></div>
            </div>
          </div>
        </section>

        <div className="layout-shell">
          <aside className="sidebar hide-mobile">
            <div className="card-flat">
              <h2 className="card-title">クイックメニュー</h2>
              <div className="quick-menu">
                <Link href="/?category=井戸端掲示板" className="quick-link"><span>井戸端掲示板</span><strong>→</strong></Link>
                <Link href="/?category=フリマ" className="quick-link"><span>フリマ</span><strong>{marketPosts.length}</strong></Link>
                <Link href="/?category=案内・募集" className="quick-link"><span>案内・募集</span><strong>→</strong></Link>
                <Link href="/?category=不動産" className="quick-link"><span>不動産</span><strong>→</strong></Link>
              </div>
            </div>

            <div className="card-flat">
              <h2 className="card-title">カテゴリ一覧</h2>
              <div className="table-like">
                {categories.map((category) => (
                  <Link key={category} href={`/?category=${encodeURIComponent(category)}`} className="quick-link">
                    <div>
                      <div style={{ fontWeight: 700 }}>{category}</div>
                      <div className="small">{categoryDescriptions[category]}</div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </aside>

          <section className="main-column">
            <div className="card composer">
              <div className="composer-head">
                <div className="avatar">井</div>
                <Link href="/posts/new" className="fake-input">何か投稿してみましょう。売ります、学校情報、募集、不動産など。</Link>
              </div>
              <div className="actions">
                <Link href="/posts/new" className="secondary">📷 画像付き投稿</Link>
                <Link href="/?category=フリマ" className="secondary">🏷 フリマを見る</Link>
                <Link href="/?category=不動産" className="secondary">🏠 不動産を見る</Link>
              </div>
            </div>

            <form className="card search-panel" action="/" method="get">
              <div className="split-actions">
                <h2 className="card-title" style={{ margin: 0 }}>投稿を探す</h2>
                <div className="small">検索条件 3項目</div>
              </div>
              <div className="form-grid">
                <select name="category" defaultValue={searchParams?.category || ''}>
                  <option value="">全カテゴリ</option>
                  {categories.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
                <select name="marketType" defaultValue={searchParams?.marketType || ''}>
                  <option value="">全フリマ区分</option>
                  <option value="売ります">売ります</option>
                  <option value="買います">買います</option>
                  <option value="譲ります">譲ります</option>
                  <option value="探しています">探しています</option>
                </select>
                <input name="q" placeholder="キーワード / 地域 / 学校名" defaultValue={searchParams?.q || ''} />
              </div>
              <div className="actions">
                <button className="primary" type="submit">検索する</button>
                <Link href="/" className="secondary">条件をクリア</Link>
              </div>
            </form>

            <section className="feed-list">
              {posts.map((post) => (
                <Link key={post.id} href={`/posts/${post.id}`} className="card feed-card">
                  <div className="feed-head">
                    <div className="feed-author">
                      <div className="avatar">{getInitial(post.authorName)}</div>
                      <div>
                        <div style={{ fontWeight: 800 }}>{post.authorName}</div>
                        <div className="feed-meta">{post.createdAt} ・ {post.area || '地域未設定'}</div>
                      </div>
                    </div>
                    <div className="actions">
                      <span className="badge">{post.category}</span>
                      {post.marketType ? <span className="badge market">{post.marketType}</span> : null}
                    </div>
                  </div>

                  <div>
                    <h3 className="feed-title">{post.title}</h3>
                    <p className="feed-excerpt">{post.body.slice(0, 160)}{post.body.length > 160 ? '…' : ''}</p>
                  </div>

                  {post.imagePaths.length > 0 ? (
                    <div className="image-grid">
                      {post.imagePaths.slice(0, 4).map((img, index) => (
                        <img key={img} src={img} alt={`投稿画像 ${index + 1}`} className="post-image" />
                      ))}
                    </div>
                  ) : null}

                  <div className="meta-row">
                    <div className="feed-meta">画像 {post.imagePaths.length} 枚 / 投稿ID #{post.id}</div>
                    <div className="actions">
                      {typeof post.price === 'number' ? <span className="badge">${post.price.toFixed(2)}</span> : null}
                      <span className="secondary">詳細を見る</span>
                    </div>
                  </div>
                </Link>
              ))}
              {posts.length === 0 ? <div className="notice">条件に一致する投稿は 0 件です。</div> : null}
            </section>
          </section>

          <aside className="sidebar">
            <div className="card-flat">
              <h2 className="card-title">このUIの改善点</h2>
              <div className="stat-list">
                <div className="stat-row"><span>上部固定ナビ</span><strong>1</strong></div>
                <div className="stat-row"><span>検索導線</span><strong>24時間すぐ到達</strong></div>
                <div className="stat-row"><span>カテゴリ数</span><strong>{categories.length}</strong></div>
                <div className="stat-row"><span>フリマ細分類</span><strong>4</strong></div>
                <div className="stat-row"><span>画像投稿</span><strong>最大4枚</strong></div>
              </div>
            </div>

            <div className="card-flat">
              <h2 className="card-title">投稿ガイド</h2>
              <div className="table-like">
                <div className="row-card">
                  <strong>1. 投稿</strong>
                  <div className="small">タイトル、本文、画像、地域、価格を入力</div>
                </div>
                <div className="row-card">
                  <strong>2. 承認待ち</strong>
                  <div className="small">スパムや誤分類を減らします</div>
                </div>
                <div className="row-card">
                  <strong>3. 公開</strong>
                  <div className="small">承認後にフィードへ表示</div>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </main>
  );
}
