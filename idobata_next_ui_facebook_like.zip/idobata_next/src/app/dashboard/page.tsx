import { redirect } from 'next/navigation';
import Link from 'next/link';
import { getCurrentUser } from '@/lib/auth';
import { getPosts } from '@/lib/db';

const statusLabels = {
  pending: '承認待ち',
  approved: '公開中',
  rejected: '差し戻し',
};

const statusClass = {
  pending: 'pending',
  approved: 'approved',
  rejected: 'rejected',
};

export default async function DashboardPage() {
  const user = await getCurrentUser();
  if (!user) redirect('/login?error=ログインが必要です');

  const posts = getPosts({ authorId: user.id, includeAllStatuses: true });

  return (
    <main className="page-section">
      <div className="container layout-shell">
        <aside className="sidebar hide-mobile">
          <div className="card-flat">
            <h2 className="card-title">アカウント</h2>
            <div className="table-like">
              <div className="row-card"><strong>名前</strong><div className="small">{user.name}</div></div>
              <div className="row-card"><strong>Email</strong><div className="small">{user.email}</div></div>
              <div className="row-card"><strong>権限</strong><div className="small">{user.role}</div></div>
            </div>
          </div>
        </aside>

        <section className="main-column">
          <div className="card hero-card">
            <span className="badge">マイ投稿管理</span>
            <h1 className="hero-title" style={{ fontSize: 34, marginTop: 10 }}>自分の投稿を一画面で管理できます。</h1>
            <p className="hero-copy">1. 投稿作成、2. 承認状況確認、3. 編集、4. 削除の 4 操作を集約しました。</p>
            <div className="actions" style={{ marginTop: 16 }}>
              <Link href="/posts/new" className="primary">新規投稿</Link>
              {user.role === 'admin' ? <Link href="/admin" className="secondary">管理者画面</Link> : null}
            </div>
          </div>

          <div className="feed-list">
            {posts.map((post) => (
              <div key={post.id} className="card feed-card">
                <div className="feed-head">
                  <div>
                    <div className="actions">
                      <span className="badge">{post.category}</span>
                      {post.marketType ? <span className="badge market">{post.marketType}</span> : null}
                      <span className={`badge ${statusClass[post.status]}`}>{statusLabels[post.status]}</span>
                    </div>
                    <h3 className="feed-title">{post.title}</h3>
                    <div className="feed-meta">投稿日 {post.createdAt} / 更新日 {post.updatedAt || '-'} / 地域 {post.area || '未設定'}</div>
                  </div>
                  <div className="small">画像 {post.imagePaths.length}枚</div>
                </div>
                <p className="feed-excerpt">{post.body.slice(0, 160)}{post.body.length > 160 ? '…' : ''}</p>
                <div className="actions">
                  <Link href={`/posts/${post.id}`} className="secondary">詳細</Link>
                  <Link href={`/posts/${post.id}/edit`} className="secondary">編集</Link>
                  <form action={`/api/posts/${post.id}/delete`} method="post">
                    <button type="submit" className="danger">削除</button>
                  </form>
                </div>
              </div>
            ))}
            {posts.length === 0 ? <div className="notice">投稿は 0 件です。</div> : null}
          </div>
        </section>

        <aside className="sidebar">
          <div className="card-flat">
            <h2 className="card-title">ダッシュボード要約</h2>
            <div className="stat-list">
              <div className="stat-row"><span>総投稿数</span><strong>{posts.length}</strong></div>
              <div className="stat-row"><span>承認待ち</span><strong>{posts.filter((p) => p.status === 'pending').length}</strong></div>
              <div className="stat-row"><span>公開中</span><strong>{posts.filter((p) => p.status === 'approved').length}</strong></div>
              <div className="stat-row"><span>差し戻し</span><strong>{posts.filter((p) => p.status === 'rejected').length}</strong></div>
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
}
