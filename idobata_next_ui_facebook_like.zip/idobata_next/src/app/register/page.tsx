import Link from 'next/link';

export default async function RegisterPage({ searchParams }: { searchParams?: Promise<{ error?: string }> }) {
  const params = (await searchParams) || {};
  return (
    <main className="page-section">
      <div className="container auth-wrap">
        <div className="card">
          <span className="badge">会員登録</span>
          <h1 className="hero-title" style={{ fontSize: 32, marginTop: 10 }}>新しいアカウントを作成</h1>
          <p className="hero-copy">登録後すぐに、投稿、画像アップロード、編集、マイ投稿管理が使えます。</p>
          {params.error ? <p className="error">{decodeURIComponent(params.error)}</p> : null}
          <form action="/api/auth/register" method="post" className="page-stack" style={{ marginTop: 18 }}>
            <div className="form-grid single">
              <input name="name" placeholder="表示名" required minLength={2} maxLength={40} />
              <input name="email" type="email" placeholder="Email" required />
              <input name="password" type="password" placeholder="Password (8文字以上)" required minLength={8} />
            </div>
            <div className="actions">
              <button className="primary" type="submit">登録する</button>
              <Link href="/login" className="secondary">ログインへ</Link>
            </div>
          </form>
        </div>
      </div>
    </main>
  );
}
