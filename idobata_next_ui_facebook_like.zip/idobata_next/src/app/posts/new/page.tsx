import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import PostForm from '@/components/PostForm';

export default async function NewPostPage() {
  const user = await getCurrentUser();
  if (!user) redirect('/login?error=ログインが必要です');

  return (
    <main className="page-section">
      <div className="container" style={{ maxWidth: 980 }}>
        <div className="card hero-card">
          <span className="badge">新規投稿</span>
          <h1 className="hero-title" style={{ fontSize: 34, marginTop: 10 }}>分かりやすい 2段構成フォームにしました。</h1>
          <p className="hero-copy">Facebook Marketplaceのように、情報入力と画像入力を分け、投稿しやすさを高めています。新規投稿は承認待ちになります。</p>
        </div>
        <div style={{ marginTop: 16 }}>
          <PostForm mode="create" action="/api/posts" />
        </div>
      </div>
    </main>
  );
}
