import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getPostById } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';

const statusLabels = {
  pending: '承認待ち',
  approved: '公開中',
  rejected: '差し戻し',
};

const statusClass = {
  pending: 'pending',
  approved: 'approved',
  rejected: 'rejected',
};

export default async function PostDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const post = getPostById(Number(id));
  const user = await getCurrentUser();
  if (!post) notFound();

  const canView = post.status === 'approved' || user?.id === post.authorId || user?.role === 'admin';
  if (!canView) notFound();

  const canEdit = user && (user.id === post.authorId || user.role === 'admin');

  return (
    <main className="page-section">
      <div className="container" style={{ maxWidth: 980 }}>
        <div className="detail-layout">
          <div className="card">
            <div className="split-actions">
              <div className="actions">
                <span className="badge">{post.category}</span>
                {post.marketType ? <span className="badge market">{post.marketType}</span> : null}
                <span className={`badge ${statusClass[post.status]}`}>{statusLabels[post.status]}</span>
              </div>
              <div className="actions">
                <Link href="/" className="secondary">一覧へ戻る</Link>
                {canEdit ? <Link href={`/posts/${post.id}/edit`} className="secondary">編集</Link> : null}
              </div>
            </div>

            <h1 className="hero-title" style={{ fontSize: 36, marginTop: 14 }}>{post.title}</h1>
            <div className="feed-meta">投稿者 {post.authorName} / 投稿日 {post.createdAt} / 更新日 {post.updatedAt || '-'} / 地域 {post.area || '未設定'}</div>

            <div className="info-grid" style={{ marginTop: 16 }}>
              <div className="info-item"><strong>価格</strong><div className="small">{typeof post.price === 'number' ? `$${post.price.toFixed(2)}` : '未設定'}</div></div>
              <div className="info-item"><strong>連絡先</strong><div className="small">{post.contact || '未設定'}</div></div>
            </div>

            {post.imagePaths.length > 0 ? (
              <div style={{ marginTop: 18 }}>
                <h2 className="card-title">画像 {post.imagePaths.length} 枚</h2>
                <div className="image-grid">
                  {post.imagePaths.map((img, index) => (
                    <img key={img} src={img} alt={`投稿画像 ${index + 1}`} className="post-image" />
                  ))}
                </div>
              </div>
            ) : null}

            <div style={{ marginTop: 18 }} className="detail-body">{post.body}</div>
          </div>
        </div>
      </div>
    </main>
  );
}
