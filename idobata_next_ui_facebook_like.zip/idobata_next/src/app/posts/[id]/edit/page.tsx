import { notFound, redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { getPostById } from '@/lib/db';
import PostForm from '@/components/PostForm';

export default async function EditPostPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect('/login?error=ログインが必要です');

  const { id } = await params;
  const post = getPostById(Number(id));
  if (!post) notFound();
  if (post.authorId !== user.id && user.role !== 'admin') redirect('/dashboard');

  return (
    <main className="page-section">
      <div className="container" style={{ maxWidth: 980 }}>
        <div className="card hero-card">
          <span className="badge">投稿編集</span>
          <h1 className="hero-title" style={{ fontSize: 34, marginTop: 10 }}>編集後は自動で再承認フローに戻ります。</h1>
          <p className="hero-copy">既存画像の削除と新規画像の追加を同じ画面で行えます。</p>
        </div>
        <div style={{ marginTop: 16 }}>
          <PostForm mode="edit" action={`/api/posts/${post.id}/update`} post={post} />
        </div>
      </div>
    </main>
  );
}
