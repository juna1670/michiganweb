import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { approvePost } from '@/lib/db';

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.redirect(new URL('/login?error=ログインが必要です', request.url));
  if (user.role !== 'admin') return NextResponse.redirect(new URL('/dashboard', request.url));

  const { id } = await params;
  approvePost(Number(id), user.id);
  return NextResponse.redirect(new URL('/admin', request.url));
}
