import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { createUser, findUserByEmail } from '@/lib/db';
import { setSession } from '@/lib/auth';

export async function POST(request: Request) {
  const formData = await request.formData();
  const name = String(formData.get('name') || '').trim();
  const email = String(formData.get('email') || '').trim().toLowerCase();
  const password = String(formData.get('password') || '');

  if (name.length < 2 || password.length < 8) {
    return NextResponse.redirect(new URL('/register?error=入力条件を満たしていません', request.url));
  }
  if (findUserByEmail(email)) {
    return NextResponse.redirect(new URL('/register?error=そのEmailは既に登録済みです', request.url));
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const result = createUser(name, email, passwordHash);
  await setSession(Number(result.lastInsertRowid));

  return NextResponse.redirect(new URL('/dashboard', request.url));
}
