import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { findUserByEmail } from '@/lib/db';
import { setSession } from '@/lib/auth';

export async function POST(request: Request) {
  const formData = await request.formData();
  const email = String(formData.get('email') || '').trim().toLowerCase();
  const password = String(formData.get('password') || '');

  const user = findUserByEmail(email);
  if (!user) {
    return NextResponse.redirect(new URL('/login?error=メールアドレスまたはパスワードが違います', request.url));
  }

  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) {
    return NextResponse.redirect(new URL('/login?error=メールアドレスまたはパスワードが違います', request.url));
  }

  await setSession(user.id);
  return NextResponse.redirect(new URL('/dashboard', request.url));
}
