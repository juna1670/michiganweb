import { NextResponse } from 'next/server';
import { createPost } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';
import { categories, marketTypes, type Category, type MarketType } from '@/lib/types';
import { saveUploadedFiles } from '@/lib/uploads';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.redirect(new URL('/login?error=ログインが必要です', request.url));
  }

  const formData = await request.formData();
  const title = String(formData.get('title') || '').trim();
  const body = String(formData.get('body') || '').trim();
  const category = String(formData.get('category') || '').trim() as Category;
  const marketTypeRaw = String(formData.get('marketType') || '').trim();
  const area = String(formData.get('area') || '').trim();
  const contact = String(formData.get('contact') || '').trim();
  const priceRaw = String(formData.get('price') || '').trim();
  const uploaded = formData.getAll('images').filter((item): item is File => item instanceof File && item.size > 0);

  if (!title || !body || !categories.includes(category)) {
    return NextResponse.redirect(new URL('/posts/new', request.url));
  }

  let marketType: MarketType = null;
  if (category === 'フリマ') {
    if (!marketTypes.includes(marketTypeRaw as Exclude<MarketType, null>)) {
      return NextResponse.redirect(new URL('/posts/new', request.url));
    }
    marketType = marketTypeRaw as MarketType;
  }

  const price = priceRaw ? Number(priceRaw) : null;
  const imagePaths = await saveUploadedFiles(uploaded.slice(0, 4));

  createPost({
    title,
    body,
    category,
    marketType,
    area,
    price: Number.isFinite(price as number) ? price : null,
    contact,
    imagePaths,
    status: 'pending',
    authorId: user.id,
  });

  return NextResponse.redirect(new URL('/dashboard', request.url));
}
