import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { deletePost, getPostById, removeFiles } from '@/lib/db';

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.redirect(new URL('/login?error=ログインが必要です', request.url));

  const { id } = await params;
  const post = getPostById(Number(id));
  if (!post) return NextResponse.redirect(new URL('/dashboard', request.url));
  if (post.authorId !== user.id && user.role !== 'admin') return NextResponse.redirect(new URL('/dashboard', request.url));

  removeFiles(post.imagePaths);
  deletePost(post.id);
  return NextResponse.redirect(new URL('/dashboard', request.url));
}
