import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getPostById, removeFiles, updatePost } from '@/lib/db';
import { categories, marketTypes, type Category, type MarketType } from '@/lib/types';
import { saveUploadedFiles } from '@/lib/uploads';

export const runtime = 'nodejs';

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.redirect(new URL('/login?error=ログインが必要です', request.url));

  const { id } = await params;
  const post = getPostById(Number(id));
  if (!post) return NextResponse.redirect(new URL('/dashboard', request.url));
  if (post.authorId !== user.id && user.role !== 'admin') return NextResponse.redirect(new URL('/dashboard', request.url));

  const formData = await request.formData();
  const title = String(formData.get('title') || '').trim();
  const body = String(formData.get('body') || '').trim();
  const category = String(formData.get('category') || '').trim() as Category;
  const marketTypeRaw = String(formData.get('marketType') || '').trim();
  const area = String(formData.get('area') || '').trim();
  const contact = String(formData.get('contact') || '').trim();
  const priceRaw = String(formData.get('price') || '').trim();
  const removeImages = formData.getAll('removeImages').map(String);
  const uploaded = formData.getAll('images').filter((item): item is File => item instanceof File && item.size > 0);

  if (!title || !body || !categories.includes(category)) {
    return NextResponse.redirect(new URL(`/posts/${id}/edit`, request.url));
  }

  let marketType: MarketType = null;
  if (category === 'フリマ') {
    if (!marketTypes.includes(marketTypeRaw as Exclude<MarketType, null>)) {
      return NextResponse.redirect(new URL(`/posts/${id}/edit`, request.url));
    }
    marketType = marketTypeRaw as MarketType;
  }

  const existingKept = post.imagePaths.filter((img) => !removeImages.includes(img));
  const newImages = await saveUploadedFiles(uploaded.slice(0, Math.max(0, 4 - existingKept.length)));
  const merged = [...existingKept, ...newImages].slice(0, 4);
  removeFiles(removeImages);

  const price = priceRaw ? Number(priceRaw) : null;
  updatePost({
    id: post.id,
    title,
    body,
    category,
    marketType,
    area,
    price: Number.isFinite(price as number) ? price : null,
    contact,
    imagePaths: merged,
    status: 'pending',
  });

  return NextResponse.redirect(new URL('/dashboard', request.url));
}
