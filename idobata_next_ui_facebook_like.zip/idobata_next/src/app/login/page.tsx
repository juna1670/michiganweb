import Link from 'next/link';

export default async function LoginPage({ searchParams }: { searchParams?: Promise<{ error?: string }> }) {
  const params = (await searchParams) || {};
  return (
    <main className="page-section">
      <div className="container auth-wrap">
        <div className="card">
          <span className="badge">ログイン</span>
          <h1 className="hero-title" style={{ fontSize: 32, marginTop: 10 }}>アカウントにログイン</h1>
          <p className="hero-copy">Facebookのように、まずログインしてから投稿・編集・承認状況の確認ができます。</p>
          {params.error ? <p className="error">{decodeURIComponent(params.error)}</p> : null}
          <form action="/api/auth/login" method="post" className="page-stack" style={{ marginTop: 18 }}>
            <div className="form-grid single">
              <input name="email" type="email" placeholder="Email" required />
              <input name="password" type="password" placeholder="Password" required />
            </div>
            <div className="actions">
              <button className="primary" type="submit">ログイン</button>
              <Link href="/register" className="secondary">会員登録</Link>
            </div>
          </form>
        </div>
      </div>
    </main>
  );
}
