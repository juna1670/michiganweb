import './globals.css';
import type { Metadata } from 'next';
import Header from '@/components/Header';

export const metadata: Metadata = {
  title: 'ミシガンいどばた+ | モダン地域コミュニティ',
  description: 'Facebookのような使いやすさを意識した、ログイン・画像・承認付きの地域掲示板',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ja">
      <body>
        <Header />
        {children}
        <footer className="footer">
          <div className="container">
            <div className="footer-inner">Next.js / ログイン / 画像4枚 / 投稿編集削除 / 管理者承認 / モダンSNS風UI</div>
          </div>
        </footer>
      </body>
    </html>
  );
}
