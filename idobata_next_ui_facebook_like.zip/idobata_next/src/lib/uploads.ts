import fs from 'fs';
import path from 'path';
import { randomUUID } from 'crypto';

const uploadDir = path.join(process.cwd(), 'public', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

export async function saveUploadedFiles(files: File[]): Promise<string[]> {
  const saved: string[] = [];
  for (const file of files) {
    if (!file || file.size === 0) continue;
    const mime = file.type || '';
    if (!mime.startsWith('image/')) continue;
    const ext = path.extname(file.name || '').toLowerCase() || '.jpg';
    const fileName = `${Date.now()}-${randomUUID()}${ext}`;
    const filePath = path.join(uploadDir, fileName);
    const bytes = await file.arrayBuffer();
    fs.writeFileSync(filePath, Buffer.from(bytes));
    saved.push(`/uploads/${fileName}`);
  }
  return saved;
}
