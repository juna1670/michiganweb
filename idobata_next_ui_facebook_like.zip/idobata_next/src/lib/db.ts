import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { categories, marketTypes, type Category, type MarketType, type PostRow, type PostStatus, type UserRole } from './types';

const dataDir = path.join(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const uploadsDir = path.join(process.cwd(), 'public', 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const dbPath = path.join(dataDir, 'idobata.db');
const db = new Database(dbPath);

db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'member',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  category TEXT NOT NULL,
  market_type TEXT,
  area TEXT,
  price REAL,
  contact TEXT,
  image_paths TEXT NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'pending',
  updated_at TEXT,
  approved_at TEXT,
  approved_by INTEGER,
  author_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (author_id) REFERENCES users(id),
  FOREIGN KEY (approved_by) REFERENCES users(id)
);
`);

function ensureColumn(table: string, column: string, definition: string) {
  const columns = db.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
  if (!columns.some((c) => c.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}

ensureColumn('users', 'role', `TEXT NOT NULL DEFAULT 'member'`);
ensureColumn('posts', 'image_paths', `TEXT NOT NULL DEFAULT '[]'`);
ensureColumn('posts', 'status', `TEXT NOT NULL DEFAULT 'pending'`);
ensureColumn('posts', 'updated_at', `TEXT`);
ensureColumn('posts', 'approved_at', `TEXT`);
ensureColumn('posts', 'approved_by', `INTEGER`);

const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get() as { count: number };
if (userCount.count === 0) {
  const passwordHash = '$2a$10$8B7QO9.rA4Un0ZHH16zA2eE4lGcMh2s3jzvV2nJaaxB7iLZBf5wFW'; // demo1234
  const insertUser = db.prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)');
  const insertPost = db.prepare(`INSERT INTO posts
    (title, body, category, market_type, area, price, contact, image_paths, status, author_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);

  const adminResult = insertUser.run('Demo Admin', 'admin@example.com', passwordHash, 'admin');
  const adminId = Number(adminResult.lastInsertRowid);
  const memberResult = insertUser.run('Demo User', 'demo@example.com', passwordHash, 'member');
  const demoUserId = Number(memberResult.lastInsertRowid);

  insertPost.run('日本食スーパーのおすすめを教えてください', 'Novi周辺で品質が良い日本食スーパーを探しています。', '井戸端掲示板', null, 'Novi', null, 'demo@example.com', '[]', 'approved', demoUserId);
  insertPost.run('炊飯器を売ります', '象印 5.5合、使用1年、状態良好です。写真は後日追加予定。', 'フリマ', '売ります', 'Ann Arbor', 60, 'demo@example.com', '[]', 'approved', demoUserId);
  insertPost.run('補習校の情報交換', '土曜校・日本語学習の情報交換ができる方を募集しています。', '案内・募集', null, 'Northville', null, 'demo@example.com', '[]', 'pending', demoUserId);
  db.prepare('UPDATE posts SET approved_by = ?, approved_at = CURRENT_TIMESTAMP WHERE status = ?').run(adminId, 'approved');
} else {
  db.prepare("UPDATE users SET role = 'admin' WHERE email = 'admin@example.com'").run();
}

export type UserRow = {
  id: number;
  name: string;
  email: string;
  password_hash: string;
  role: UserRole;
};

function parseImagePaths(raw: string | null): string[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((v) => typeof v === 'string') : [];
  } catch {
    return [];
  }
}

function mapPost(row: any): PostRow {
  return {
    ...row,
    imagePaths: parseImagePaths(row.imagePaths),
  } as PostRow;
}

export function createUser(name: string, email: string, passwordHash: string, role: UserRole = 'member') {
  return db
    .prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)')
    .run(name, email.toLowerCase(), passwordHash, role);
}

export function findUserByEmail(email: string): UserRow | undefined {
  return db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase()) as UserRow | undefined;
}

export function findUserById(id: number): Omit<UserRow, 'password_hash'> | undefined {
  return db.prepare('SELECT id, name, email, role FROM users WHERE id = ?').get(id) as Omit<UserRow, 'password_hash'> | undefined;
}

export function createPost(input: {
  title: string;
  body: string;
  category: Category;
  marketType: MarketType;
  area?: string;
  price?: number | null;
  contact?: string;
  imagePaths?: string[];
  status?: PostStatus;
  authorId: number;
}) {
  return db
    .prepare(`INSERT INTO posts (title, body, category, market_type, area, price, contact, image_paths, status, author_id, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`)
    .run(
      input.title,
      input.body,
      input.category,
      input.marketType,
      input.area || null,
      input.price ?? null,
      input.contact || null,
      JSON.stringify(input.imagePaths || []),
      input.status || 'pending',
      input.authorId,
    );
}

export function updatePost(input: {
  id: number;
  title: string;
  body: string;
  category: Category;
  marketType: MarketType;
  area?: string;
  price?: number | null;
  contact?: string;
  imagePaths?: string[];
  status?: PostStatus;
}) {
  return db
    .prepare(`UPDATE posts SET
      title = ?, body = ?, category = ?, market_type = ?, area = ?, price = ?, contact = ?, image_paths = ?, status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?`)
    .run(
      input.title,
      input.body,
      input.category,
      input.marketType,
      input.area || null,
      input.price ?? null,
      input.contact || null,
      JSON.stringify(input.imagePaths || []),
      input.status || 'pending',
      input.id,
    );
}

export function approvePost(postId: number, adminId: number) {
  return db.prepare(`UPDATE posts SET status = 'approved', approved_at = CURRENT_TIMESTAMP, approved_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(adminId, postId);
}

export function rejectPost(postId: number, adminId: number) {
  return db.prepare(`UPDATE posts SET status = 'rejected', approved_at = CURRENT_TIMESTAMP, approved_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(adminId, postId);
}

export function deletePost(postId: number) {
  return db.prepare('DELETE FROM posts WHERE id = ?').run(postId);
}

export function getPosts(filters?: {
  category?: string;
  marketType?: string;
  q?: string;
  authorId?: number;
  status?: PostStatus;
  includeAllStatuses?: boolean;
}): PostRow[] {
  const where: string[] = [];
  const params: Array<string | number> = [];

  if (filters?.category && categories.includes(filters.category as Category)) {
    where.push('p.category = ?');
    params.push(filters.category);
  }
  if (filters?.marketType && marketTypes.includes(filters.marketType as Exclude<MarketType, null>)) {
    where.push('p.market_type = ?');
    params.push(filters.marketType);
  }
  if (filters?.q) {
    where.push('(p.title LIKE ? OR p.body LIKE ? OR IFNULL(p.area, "") LIKE ?)');
    params.push(`%${filters.q}%`, `%${filters.q}%`, `%${filters.q}%`);
  }
  if (typeof filters?.authorId === 'number') {
    where.push('p.author_id = ?');
    params.push(filters.authorId);
  }

  if (filters?.status) {
    where.push('p.status = ?');
    params.push(filters.status);
  } else if (!filters?.includeAllStatuses && typeof filters?.authorId !== 'number') {
    where.push("p.status = 'approved'");
  }

  const sql = `
    SELECT p.id, p.title, p.body, p.category, p.market_type as marketType, p.area, p.price,
           p.contact, p.author_id as authorId, u.name as authorName, p.created_at as createdAt,
           p.updated_at as updatedAt, p.status as status, p.image_paths as imagePaths
    FROM posts p
    JOIN users u ON u.id = p.author_id
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    ORDER BY p.created_at DESC, p.id DESC
  `;

  return (db.prepare(sql).all(...params) as any[]).map(mapPost);
}

export function getPostById(id: number): PostRow | undefined {
  const row = db.prepare(`
    SELECT p.id, p.title, p.body, p.category, p.market_type as marketType, p.area, p.price,
           p.contact, p.author_id as authorId, u.name as authorName, p.created_at as createdAt,
           p.updated_at as updatedAt, p.status as status, p.image_paths as imagePaths
    FROM posts p
    JOIN users u ON u.id = p.author_id
    WHERE p.id = ?
  `).get(id) as any;
  return row ? mapPost(row) : undefined;
}

export function countPendingPosts(): number {
  const row = db.prepare("SELECT COUNT(*) as count FROM posts WHERE status = 'pending'").get() as { count: number };
  return row.count;
}

export function removeFiles(pathsToDelete: string[]) {
  for (const publicPath of pathsToDelete) {
    const relative = publicPath.replace(/^\/+/, '');
    const absPath = path.join(process.cwd(), 'public', relative.replace(/^uploads\//, 'uploads/'));
    if (fs.existsSync(absPath)) {
      try { fs.unlinkSync(absPath); } catch {}
    }
  }
}
