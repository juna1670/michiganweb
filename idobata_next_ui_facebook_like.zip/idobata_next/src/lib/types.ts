export type Category = '井戸端掲示板' | 'フリマ' | '案内・募集' | '不動産';
export type MarketType = '売ります' | '買います' | '譲ります' | '探しています' | null;
export type PostStatus = 'pending' | 'approved' | 'rejected';
export type UserRole = 'member' | 'admin';

export type PostRow = {
  id: number;
  title: string;
  body: string;
  category: Category;
  marketType: MarketType;
  area: string | null;
  price: number | null;
  contact: string | null;
  authorId: number;
  authorName: string;
  createdAt: string;
  updatedAt: string | null;
  status: PostStatus;
  imagePaths: string[];
};

export const categories: Category[] = ['井戸端掲示板', 'フリマ', '案内・募集', '不動産'];
export const marketTypes: Exclude<MarketType, null>[] = ['売ります', '買います', '譲ります', '探しています'];
export const postStatuses: PostStatus[] = ['pending', 'approved', 'rejected'];
