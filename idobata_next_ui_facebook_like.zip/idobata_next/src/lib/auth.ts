import { cookies } from 'next/headers';
import { createHash } from 'crypto';
import { findUserById } from './db';

const SESSION_COOKIE = 'idobata_session';

function sign(value: string) {
  const secret = process.env.SESSION_SECRET || 'dev-secret-change-me';
  return createHash('sha256').update(`${value}:${secret}`).digest('hex');
}

export async function setSession(userId: number) {
  const cookieStore = await cookies();
  const payload = `${userId}.${sign(String(userId))}`;
  cookieStore.set(SESSION_COOKIE, payload, {
    httpOnly: true,
    sameSite: 'lax',
    secure: false,
    path: '/',
    maxAge: 60 * 60 * 24 * 14,
  });
}

export async function clearSession() {
  const cookieStore = await cookies();
  cookieStore.delete(SESSION_COOKIE);
}

export async function getCurrentUser() {
  const cookieStore = await cookies();
  const raw = cookieStore.get(SESSION_COOKIE)?.value;
  if (!raw) return null;

  const [userId, signature] = raw.split('.');
  if (!userId || !signature || sign(userId) !== signature) return null;

  const user = findUserById(Number(userId));
  return user ?? null;
}
